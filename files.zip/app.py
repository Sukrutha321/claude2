"""
CodeGenie - AI Code Generator Backend
Flask application with Hugging Face integration
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
import os
from datetime import datetime
import requests

app = Flask(__name__)
app.secret_key = 'your-secret-key-here-change-in-production'  # Change this!
CORS(app)

# Hugging Face API Configuration
HUGGINGFACE_API_TOKEN = os.environ.get('HUGGINGFACE_API_TOKEN', 'your-hf-token-here')
API_URL = "https://api-inference.huggingface.co/models/codellama/CodeLlama-7b-hf"

# Mock user database (replace with actual database)
users = {
    'demo@codegenie.dev': {
        'password': 'Demo2024!',
        'name': 'Demo User'
    }
}

# ============= Routes =============

@app.route('/')
def index():
    """Serve the login page"""
    return render_template('login.html')

@app.route('/homepage')
def homepage():
    """Serve the homepage (requires login)"""
    if 'user' not in session:
        return redirect(url_for('index'))
    return render_template('homepage.html', user=session['user'])

# ============= API Endpoints =============

@app.route('/api/login', methods=['POST'])
def login():
    """Handle user login"""
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    if email in users and users[email]['password'] == password:
        session['user'] = {
            'email': email,
            'name': users[email]['name']
        }
        return jsonify({
            'success': True,
            'message': 'Login successful',
            'user': session['user']
        })
    else:
        return jsonify({
            'success': False,
            'message': 'Invalid credentials'
        }), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    """Handle user logout"""
    session.pop('user', None)
    return jsonify({'success': True, 'message': 'Logged out successfully'})

@app.route('/api/signup', methods=['POST'])
def signup():
    """Handle user signup"""
    data = request.json
    name = data.get('name')
    email = data.get('email')
    password = data.get('password')
    
    # Validate input
    if not all([name, email, password]):
        return jsonify({
            'success': False,
            'message': 'All fields are required'
        }), 400
    
    # Check if user already exists
    if email in users:
        return jsonify({
            'success': False,
            'message': 'Email already registered'
        }), 400
    
    # In production, hash the password!
    users[email] = {
        'name': name,
        'password': password  # USE HASHING IN PRODUCTION!
    }
    
    return jsonify({
        'success': True,
        'message': 'Account created successfully'
    })

@app.route('/api/generate', methods=['POST'])
def generate_code():
    """
    Generate code from natural language prompt using Hugging Face
    
    Expected JSON payload:
    {
        "prompt": "Create a function to calculate factorial",
        "language": "python"
    }
    """
    if 'user' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        prompt = data.get('prompt', '')
        language = data.get('language', 'python')
        
        if not prompt:
            return jsonify({'error': 'Prompt is required'}), 400
        
        # Format the prompt for code generation
        formatted_prompt = format_prompt(prompt, language)
        
        # Call Hugging Face API
        generated_code = call_huggingface_api(formatted_prompt)
        
        return jsonify({
            'success': True,
            'code': generated_code,
            'language': language,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/explain', methods=['POST'])
def explain_code():
    """
    Convert code to natural language explanation
    
    Expected JSON payload:
    {
        "code": "def factorial(n): ...",
        "language": "python"
    }
    """
    if 'user' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        code = data.get('code', '')
        language = data.get('language', 'python')
        
        if not code:
            return jsonify({'error': 'Code is required'}), 400
        
        # Format the prompt for code explanation
        formatted_prompt = f"Explain this {language} code in simple terms:\n\n{code}"
        
        # Call Hugging Face API
        explanation = call_huggingface_api(formatted_prompt)
        
        return jsonify({
            'success': True,
            'explanation': explanation,
            'language': language,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# ============= Helper Functions =============

def format_prompt(prompt, language):
    """Format the user prompt for the AI model"""
    language_templates = {
        'python': f"Write Python code for the following task:\n{prompt}\n\nPython code:",
        'javascript': f"Write JavaScript code for the following task:\n{prompt}\n\nJavaScript code:",
        'java': f"Write Java code for the following task:\n{prompt}\n\nJava code:",
        'cpp': f"Write C++ code for the following task:\n{prompt}\n\nC++ code:"
    }
    
    return language_templates.get(language, f"Write {language} code:\n{prompt}")

def call_huggingface_api(prompt, max_length=500):
    """
    Call Hugging Face Inference API
    
    Note: You'll need to sign up at https://huggingface.co/
    and get an API token from https://huggingface.co/settings/tokens
    """
    headers = {
        "Authorization": f"Bearer {HUGGINGFACE_API_TOKEN}"
    }
    
    payload = {
        "inputs": prompt,
        "parameters": {
            "max_length": max_length,
            "temperature": 0.7,
            "top_p": 0.95,
            "do_sample": True
        }
    }
    
    try:
        response = requests.post(API_URL, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        # Extract generated text
        if isinstance(result, list) and len(result) > 0:
            generated_text = result[0].get('generated_text', '')
            # Clean up the output (remove the original prompt)
            generated_code = generated_text.replace(prompt, '').strip()
            return generated_code
        else:
            return result.get('generated_text', 'Error generating code')
            
    except requests.exceptions.RequestException as e:
        print(f"API Error: {e}")
        # Fallback to demo code if API fails
        return get_demo_code(prompt)

def get_demo_code(prompt):
    """Fallback demo code when API is unavailable"""
    return f"""# Demo code (API not configured)
# Original prompt: {prompt}

def example_function():
    '''
    This is a demo placeholder.
    Configure your Hugging Face API token to get real AI-generated code.
    '''
    pass
"""

# ============= Error Handlers =============

@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'Route not found'}), 404

@app.errorhandler(500)
def internal_error(e):
    return jsonify({'error': 'Internal server error'}), 500

# ============= Main =============

if __name__ == '__main__':
    # In production, use a proper WSGI server like Gunicorn
    app.run(debug=True, host='0.0.0.0', port=5000)
